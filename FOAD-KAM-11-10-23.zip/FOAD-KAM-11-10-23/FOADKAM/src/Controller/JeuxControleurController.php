<?php

namespace App\Controller;

use App\Repository\JeuxRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class JeuxControleurController extends AbstractController
{
    #[Route('/jeux/controleur', name: 'app_jeux_controleur')]
    public function index(JeuxRepository $JeuxRepository): Response
    {
        // Récupérez ici la liste des jeux vidéo depuis la base de données
        $jeuxVideo = $JeuxRepository->findAll();
        return $this->render('jeux_controleur/index.html.twig', [
            'jeuxVideo' => $jeuxVideo,
        ]);
    }
}
